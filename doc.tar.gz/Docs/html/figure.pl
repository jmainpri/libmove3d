<LI><A NAME="tex2html8" HREF="node6.html#139">
Description of a face of a general polyhedron
</A>
<LI><A NAME="tex2html17" HREF="node7.html#205">
The geometric primitives proposed in Move3D
</A>
<LI><A NAME="tex2html23" HREF="node8.html#258">
Description of a scene in Move3D.
</A>
<LI><A NAME="tex2html104" HREF="node25.html#521">
Setting the position of the current robot.
</A>
<LI><A NAME="tex2html120" HREF="node29.html#648">
Example of local path built by <TT>p3d_linear_search</TT>.
</A>
<LI><A NAME="tex2html121" HREF="node29.html#650">
Example of local path built by <TT>p3d_local_search</TT>.
</A>
<LI><A NAME="tex2html122" HREF="node29.html#652">
Example of local path built by <TT>p3d_platform_search</TT>.
</A>
<LI><A NAME="tex2html123" HREF="node29.html#654">
Example of local path built by <TT>p3d_manhattan_search</TT>.
</A>
<LI><A NAME="tex2html129" HREF="node30.html#637">
Validation of a local path in Move3D.
</A>
