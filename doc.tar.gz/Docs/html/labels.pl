# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate labels original text with physical files.

$key = q/model/;
${$key} = 'node2.html'; 
$key = q/global/;
${$key} = 'node31.html'; 
$key = q/FIG_LOCAL_RS_SEG/;
${$key} = 'node29.html'; 
$key = q/FIG_FACE/;
${$key} = 'node6.html'; 
$key = q/FIG_SETPOS1/;
${$key} = 'node25.html'; 
$key = q/FIG_LOCAL_RS/;
${$key} = 'node29.html'; 
$key = q/external_labels/;
${$key} = ''; 
$key = q/FIG_VALID/;
${$key} = 'node30.html'; 
$key = q/FIG_LOCAL_MAN/;
${$key} = 'node29.html'; 
$key = q/FIG_ROBOT/;
${$key} = 'node8.html'; 
$key = q/FIG_PRIM/;
${$key} = 'node7.html'; 
$key = q/FIG_LOCAL_SEG/;
${$key} = 'node29.html'; 
$key = q/datastruct/;
${$key} = 'node43.html'; 

1;

